#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "Subject.h"

/*
   method 	 1.모든 과목 불러오기
			 2.사용자로부터 이수한 과목 입력받기
			 3.남은학점 계산....
			 4.(각 학년별, 각 학기별 이수가능한 과목)  출력
*/


class subject_DB {
private:
	std::vector <subject_class> subjectListDB;
	/*int number;
	int majorInfo; //전공기초: 0 전공필수: 1 전공: 2
	int grade; //1학년: 1 2학년:2
	int semester; // 1학기: 1 2학기: 2
	int credit;
	std::string sub_name; //교과목 이름*/
	unsigned int totalLength = 0;

public:
	void init_DB();
	void get_comp_sub();
	void cal_rest_credit();
	void sub_print();
	bool searchSubject(std::string subName);


};

void subject_DB::init_DB() {


	std::fstream in;
	std::string data;
	int i = 0, cnt = 1; 
	
	in.open("studentdb.txt", std::ios::in);

	if (in) {
		subject_class sub;
		while (!in.eof()) {
			//들어오는 데이터 순서 : index, 구분, 학년, 학기, 학점, 교과목

			std::getline(in, data, ',');
			int flag = 0;

			switch (cnt % 6) {
			case 1:
				sub.setNumber(stoi(data));
				cnt++;
				break;

			case 2:
				if (data == "전공기초") {
					flag = 0;
				}
				else if (data == "전공필수") {
					flag = 1;
				}
				else {
					flag = 2;
				}
				sub.setMajorInfo(flag);
				cnt++;
				break;

			case 3:
				sub.setGrade(stoi(data));
				cnt++;
				break;

			case 4:
				sub.setSemester(stoi(data));
				cnt++;
				break;

			case 5:
				sub.setCredit(stoi(data));
				cnt++;
				break;

			case 0:
				sub.setName(data);
				cnt++;
				subjectListDB.push_back(sub);
				break;

			}

		}

		totalLength = subjectListDB.size();
	}
	else {
		std::cout << "파일을 찾을 수 없습니다!" << std::endl;
	}

	//for (int i = 0; i < 66; i++) {
	//	std::cout << i << "번째 subject 입니다." << std::endl;
	//	std::cout << "번호:" << subjectArray[i].number << std::endl;
	//	std::cout << "구분:" << subjectArray[i].majorInfo << std::endl;
	//	std::cout << "학년:" << subjectArray[i].grade << std::endl;
	//	std::cout << "학기:" << subjectArray[i].semester << std::endl;
	//	std::cout << "학점:" << subjectArray[i].credit << std::endl;
	//	std::cout << ":" << subjectArray[i]->getNumber() << std::endl;
	//}



}

/*
method 	 1.모든 과목 불러오기
2.사용자로부터 이수한 과목 입력받기
3.남은학점 계산....
4.(각 학년별, 각 학기별 이수가능한 과목)  출력
*/
void subject_DB::get_comp_sub() {
	//출력
	for (size_t i = 0; i < subjectListDB.size(); i++) {
		std::cout << "number :" << subjectListDB[i].getCredit() << std::endl;
		std::cout << "subject name :" << subjectListDB[i].getsub_name() << std::endl;
	}

	//사용자로부터 입력
	std::string temp;
	int i = 0;
	std::cout << "> ";
	std::getline(std::cin, temp);
	do {
		if (temp[i] != ' ')
			subjectListDB[temp[i]].setSignal();
		i++;
	} while (temp[i] != '\0');
	//2 4 6 7 8 => split!

}

void subject_DB::cal_rest_credit() {
	int comp_credit = 0;
	for (size_t i = 0; i < subjectListDB.size(); i++) {
		if (subjectListDB[i].getSignal()) {
			comp_credit += subjectListDB[i].getCredit();
		}
	}
}

// find an
bool subject_DB::searchSubject(std::string subName)
{
	for (size_t i = 0; i < subjectListDB.size(); i++) {
		if (subjectListDB[i].getsub_name() == subName) {
			return true;
		}
	}
	return false;
}